/*
 * tcp_demo.h
 *
 *  Created on: 2020年4月29日
 *      Author: LiZhiqiang
 */

#ifndef THIRD_PARTY_INTERNET_INC_TCP_DEMO_H_
#define THIRD_PARTY_INTERNET_INC_TCP_DEMO_H_


extern uint16 W5500_tcp_server_port;
void do_tcp_server(void);//TCP Server回环演示函数
void do_tcp_client(void);//TCP Clinet回环演示函数

#endif /* THIRD_PARTY_INTERNET_INC_TCP_DEMO_H_ */
