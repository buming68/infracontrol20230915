/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * File Name          : freertos.c
  * Description        : Code for freertos applications
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <string.h>
#include "stdio.h"
#include "tim.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */
uint32_t send_Code = 0;
uint8_t userdata1 = 0x57, userdate2 = 0x59, userdata3 = 0x58; 
uint8_t data1 = 0x30, data2 = 0x32;     //test data "2" keycode = 0x30,0x32

int channel[12] = {1, 2, 3, 4, 5, 6, 88, 95, 152, 153, 154, 155}; //����+����  12��Ƶ��
int channel6[6] = {1, 2, 3, 4, 5, 6}; //6�������6������Ƶ��
/* USER CODE END Variables */
osThreadId defaultTaskHandle;
osThreadId infraTaskHandle;
osThreadId ledTaskHandle;

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */
/**
 * @brief       ��ʱnus
 * @param       nus: Ҫ��ʱ��us��.
 * @note        nusȡֵ��Χ : 0~190887435(���ֵ�� 2^32 / fac_us @fac_us = 21)
 * @retval      ��
 */
void delay_us(uint32_t nus)
{
    uint32_t ticks;
    uint32_t told, tnow, tcnt = 0;
    uint32_t reload = SysTick->LOAD;        /* LOAD��ֵ */
    ticks = nus * 72;                 /* ��Ҫ�Ľ����� */
    told = SysTick->VAL;                    /* �ս���ʱ�ļ�����ֵ */
    while (1)
    {
        tnow = SysTick->VAL;
        if (tnow != told)
        {
            if (tnow < told)
            {
                tcnt += told - tnow;        /* ����ע��һ��SYSTICK��һ���ݼ��ļ������Ϳ����� */
            }
            else 
            {
                tcnt += reload - tnow + told;
            }
            told = tnow;
            if (tcnt >= ticks)
            {
                break;                      /* ʱ�䳬��/����Ҫ�ӳٵ�ʱ��,���˳� */
            }
        }
    }
}

// �������ߺ���ң����˽��Э��  40bit
void infrasend_wxyx(uint8_t bdata){
     HAL_TIM_PWM_Start(&htim2,TIM_CHANNEL_2);        //start1
     HAL_TIM_PWM_Start(&htim2,TIM_CHANNEL_1);        //start1
    
    delay_us(3640);                                 //TVOS portocol 
    HAL_TIM_PWM_Stop(&htim2,TIM_CHANNEL_2);      
    HAL_TIM_PWM_Stop(&htim2,TIM_CHANNEL_1);   
    
    delay_us(1800);                                 //TVOS portocol 

    send_Code = userdata3<< 16 | userdate2<<8 | userdata1;
    for(int i=0; i<24; i++){        
        HAL_TIM_PWM_Start(&htim2,TIM_CHANNEL_2);
        HAL_TIM_PWM_Start(&htim2,TIM_CHANNEL_1);        
        
        delay_us(560);
        HAL_TIM_PWM_Stop(&htim2,TIM_CHANNEL_2);
        HAL_TIM_PWM_Stop(&htim2,TIM_CHANNEL_1);
        
        if((send_Code>>i) & 0x01){
            delay_us(1120);
        }
        else
            delay_us(560);
    }
    
    HAL_TIM_PWM_Start(&htim2,TIM_CHANNEL_2);        //start2
    HAL_TIM_PWM_Start(&htim2,TIM_CHANNEL_1);        //start2    
    
    delay_us(3640);                                 //TVOS portocol  
    HAL_TIM_PWM_Stop(&htim2,TIM_CHANNEL_2);   
    HAL_TIM_PWM_Stop(&htim2,TIM_CHANNEL_1); 
    
    delay_us(1800);                                 //TVOS portocol 
  
    send_Code = bdata<<8 | data1;
    for(int i=0; i<16; i++){  
        HAL_TIM_PWM_Start(&htim2,TIM_CHANNEL_2);
        HAL_TIM_PWM_Start(&htim2,TIM_CHANNEL_1);
        
        delay_us(560);
        HAL_TIM_PWM_Stop(&htim2,TIM_CHANNEL_2);        
        HAL_TIM_PWM_Stop(&htim2,TIM_CHANNEL_1);
        
        if((send_Code>>i) & 0x01)
            delay_us(1120);
        else
            delay_us(560);
    }
    
    HAL_TIM_PWM_Start(&htim2,TIM_CHANNEL_2);        //stop�����룡������
    HAL_TIM_PWM_Start(&htim2,TIM_CHANNEL_1);        //stop�����룡������
    
    delay_us(560);        
    HAL_TIM_PWM_Stop(&htim2,TIM_CHANNEL_2);
    HAL_TIM_PWM_Stop(&htim2,TIM_CHANNEL_1);    
    
    delay_us(54000);

    
//    HAL_TIM_PWM_Start(&htim2,TIM_CHANNEL_2);        //repeat code
//    delay_us(3640);             //TVOS portocol  
//    HAL_TIM_PWM_Stop(&htim2,TIM_CHANNEL_2);      
//    delay_us(3640);  
//    HAL_TIM_PWM_Start(&htim2,TIM_CHANNEL_2);        
//    delay_us(560);
//    HAL_TIM_PWM_Stop(&htim2,TIM_CHANNEL_2);  
//    delay_us(50000);
//    delay_us(50160);
}

/* USER CODE END FunctionPrototypes */

void StartDefaultTask(void const * argument);
void IngraTask(void const * argument);
void LedTask(void const * argument);

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/* GetIdleTaskMemory prototype (linked to static allocation support) */
void vApplicationGetIdleTaskMemory( StaticTask_t **ppxIdleTaskTCBBuffer, StackType_t **ppxIdleTaskStackBuffer, uint32_t *pulIdleTaskStackSize );

/* USER CODE BEGIN GET_IDLE_TASK_MEMORY */
static StaticTask_t xIdleTaskTCBBuffer;
static StackType_t xIdleStack[configMINIMAL_STACK_SIZE];

void vApplicationGetIdleTaskMemory( StaticTask_t **ppxIdleTaskTCBBuffer, StackType_t **ppxIdleTaskStackBuffer, uint32_t *pulIdleTaskStackSize )
{
  *ppxIdleTaskTCBBuffer = &xIdleTaskTCBBuffer;
  *ppxIdleTaskStackBuffer = &xIdleStack[0];
  *pulIdleTaskStackSize = configMINIMAL_STACK_SIZE;
  /* place for user code */
}
/* USER CODE END GET_IDLE_TASK_MEMORY */

/**
  * @brief  FreeRTOS initialization
  * @param  None
  * @retval None
  */
void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* definition and creation of defaultTask */
  osThreadDef(defaultTask, StartDefaultTask, osPriorityNormal, 0, 128);
  defaultTaskHandle = osThreadCreate(osThread(defaultTask), NULL);

  /* definition and creation of infraTask */
  osThreadDef(infraTask, IngraTask, osPriorityAboveNormal, 0, 128);
  infraTaskHandle = osThreadCreate(osThread(infraTask), NULL);

  /* definition and creation of ledTask */
  osThreadDef(ledTask, LedTask, osPriorityNormal, 0, 128);
  ledTaskHandle = osThreadCreate(osThread(ledTask), NULL);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

}

/* USER CODE BEGIN Header_StartDefaultTask */
/**
  * @brief  Function implementing the defaultTask thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_StartDefaultTask */
void StartDefaultTask(void const * argument)
{
  /* USER CODE BEGIN StartDefaultTask */
  /* Infinite loop */
  for(;;)
  {
    osDelay(1);
  }
  /* USER CODE END StartDefaultTask */
}

/* USER CODE BEGIN Header_IngraTask */
/**
* @brief Function implementing the infraTask thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_IngraTask */
void IngraTask(void const * argument)
{
  /* USER CODE BEGIN IngraTask */
  /* Infinite loop */
  int  channelcount = 0;
  char chstring[] = "168";    
  int j;
  for(;;)
  {
    if(HAL_GPIO_ReadPin(STATE_GPIO_Port, STATE_Pin)){
        if (channelcount >=  sizeof(channel)/sizeof(int)){     //channnelcount Ϊÿ��Ƶ���ŵļ�����һ��ѭ������һ��Ƶ��
            channelcount = 0;}
    }else{
        if (channelcount >=  sizeof(channel6)/sizeof(int)){     //channnelcount Ϊÿ��Ƶ���ŵļ�����һ��ѭ������һ��Ƶ��
            channelcount = 0;}
    }  
    if(HAL_GPIO_ReadPin(STATE_GPIO_Port, STATE_Pin)){
        sprintf(chstring, "%d", channel[channelcount]);     //��Ƶ��������ת�����ַ���   
    }else{
        sprintf(chstring, "%d", channel6[channelcount]);     //��Ƶ��������ת�����ַ���   
    }
    

  for (j = 0; j < strlen(chstring); j++) {            //��Ƶ�����ַ����������ȡ����������ָ����ַ
    infrasend_wxyx(chstring[j]);                       //�����������ߵ��ӱ�׼�Ļ����п����źţ�Ϊ����
    osDelay(800); 
            
    } 
  
    
    HAL_GPIO_TogglePin(LED_GPIO_Port,LED_Pin);
    osDelay(50);
    HAL_GPIO_TogglePin(LED_GPIO_Port,LED_Pin);
    osDelay(50);
    HAL_GPIO_TogglePin(LED_GPIO_Port,LED_Pin);
    osDelay(50);
    HAL_GPIO_TogglePin(LED_GPIO_Port,LED_Pin);
    
    channelcount++;  
    osDelay(1000);
  }
  /* USER CODE END IngraTask */
}

/* USER CODE BEGIN Header_LedTask */
/**
* @brief Function implementing the ledTask thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_LedTask */
void LedTask(void const * argument)
{
  /* USER CODE BEGIN LedTask */
  /* Infinite loop */
  for(;;)
  {
            
    //if(HAL_GPIO_ReadPin(STATE_GPIO_Port, STATE_Pin))

    HAL_GPIO_TogglePin(LED_GPIO_Port,LED_Pin);
    osDelay(1500);  
      
//    HAL_GPIO_TogglePin(LED_GPIO_Port,LED_Pin);
//    osDelay(1500);

  }
  /* USER CODE END LedTask */
}

/* Private application code --------------------------------------------------*/
/* USER CODE BEGIN Application */

/* USER CODE END Application */

